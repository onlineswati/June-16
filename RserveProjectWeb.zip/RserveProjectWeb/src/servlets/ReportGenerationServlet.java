package servlets;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utils.DateUtils;
import utils.RunReportGenProcedure;
import utils.Storage;
import constants.Init;

public class ReportGenerationServlet extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	
	private Storage storage;
	private long start;

	@Override
	public void init() throws ServletException {
		super.init();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		Init.SERVLET_CONTEXT_PATH = Init.SCRIPT_DATA_DIRECTORY;
		Init.CONTEXT_PATH=getServletContext().getRealPath("database.properties");
		try { 
			getServletContext().getRequestDispatcher("/reportGeneration.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		if(request.getSession().getAttribute("userName")==null){
			response.sendRedirect("./");
			return;
		}
		
		String batchId=request.getParameter("fileInstId");
		
		storage = new Storage();
		start = DateUtils.getTime();
		Object[] dataForSaving = { batchId, "Geo tagging", start, null,
				"Job Submitted", "",request.getSession().getAttribute("userName") };
		storage.storeDbData(dataForSaving);
		
		
		Properties properties=new Properties();
		InputStream input=new FileInputStream(getServletContext().getRealPath("server.properties"));
		properties.load(input);
		
		String uploadFolder = properties.getProperty("RuTagging.UploadFolder.Path")+File.separator+properties.getProperty("RuTagging.fileName");
		
		//File[] files=finder(uploadFolder);
		//System.out.println(files[1].getName());
		System.out.println("File Name: " + properties.getProperty("RuTagging.fileName"));
		new RunReportGenProcedure(batchId,getServletContext().getRealPath("database.properties"),properties.getProperty("RuTagging.fileName")).start();
		response.sendRedirect("/RserveProjectWeb/reportGeneration.jsp");
	}
	

	public File[] finder( String dirName){
	    File dir = new File(dirName);

	    return dir.listFiles(new FilenameFilter() { 
	             public boolean accept(File dir, String filename)
	                  { return filename.endsWith(".txt"); }
	    } );

	}


}


