package servlets;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;

import constants.Init;

public class ScriptUploadServlet extends HttpServlet{

	private final Logger LOG = Logger.getLogger(ScriptUploadServlet.class);
	
	private static final String DATA_DIRECTORY = Init.SCRIPT_DATA_DIRECTORY;
	private static final int MAX_MEMORY_SIZE = Init.MAX_MEMORY_SIZE;
	private static final int MAX_REQUEST_SIZE = Init.MAX_REQUEST_SIZE;
	
	private static final String STATUS_PAGE = Init.STATUS_PAGE;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		try {
			getServletContext().getRequestDispatcher(STATUS_PAGE).forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
				
		
		// Check that we have a file upload request
				boolean isMultipart = ServletFileUpload.isMultipartContent(request);

				if (!isMultipart) {
					return;
				}

				// Create a factory for disk-based file items
				DiskFileItemFactory factory = new DiskFileItemFactory();

				// Sets the size threshold beyond which files are written directly to disk
				factory.setSizeThreshold(MAX_MEMORY_SIZE);

				// Sets the directory used to temporarily store files that are larger
				// than the configured size threshold. We use temporary directory for java
				factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

				// constructs the folder where uploaded file will be stored
				String uploadFolder = DATA_DIRECTORY;

				File uploadFolderPath = new File(uploadFolder);
				
				if(!uploadFolderPath.exists()){
					uploadFolderPath.mkdir();
					System.out.println("Scripts dir created");
				}
				// Create a new file upload handler
				ServletFileUpload upload = new ServletFileUpload(factory);

				// Set overall request size constraint
				upload.setSizeMax(MAX_REQUEST_SIZE);

				try {
					// Parse the request
					List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
					for (FileItem item : multiparts) {

							if (!item.isFormField()) {
								String fileName = new File(item.getName()).getName();
								String filePath = uploadFolder + File.separator + fileName;
								File uploadedFile = new File(filePath);
								System.out.println("Script uploaded to: "+filePath);
								// saves the file to upload directory
								item.write(uploadedFile);
							}
					}
				} catch (FileUploadException ex) {
					LOG.error(ex);
					throw new ServletException(ex);
				} catch (Exception ex) {
					LOG.error(ex);
					throw new ServletException(ex);
				}

	}
}